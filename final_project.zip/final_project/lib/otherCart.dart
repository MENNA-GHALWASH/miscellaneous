import 'package:flutter/material.dart';

import 'homeScreen2.dart';

void main() {
  runApp(MaterialApp(home: OthCart(),));
}

class OthCart extends StatefulWidget {
  @override
  _OthCartState createState() => _OthCartState();
}

class _OthCartState extends State<OthCart> {
  List<String> _imagesAssets = [
    'assets/o1.png',
    'assets/o2.png',
    'assets/o3.png',
    'assets/o4.png',];

 /* List<String> _imageLabels = [
    'Image 1',
    'Image 2',
    'Image 3',
    'Image 4',
    'Image 5',
    'Image 6',
    'Image 7',
    'Image 8',
    'Image 9',
    'Image 10',
  ];
*/
  var s = sidebar();

  List<bool> _likedImages = List.generate(10, (_) => false);
  List<bool> _cartedImages = List.generate(10, (_) => false);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.deepPurpleAccent[100],
        title: Text('other'),
      ),
      drawer: s,
      body: ListView.builder(
        itemCount: _imagesAssets.length,
        itemBuilder: (context, index) {
          return GestureDetector(
            onTap: () {
              setState(() {
                _likedImages[index] = !_likedImages[index];
              });
            },
            child: Card(
              child: Column(
                children: [
                  Image(image: AssetImage(
                    _imagesAssets[index],
                  ),
                    fit: BoxFit.cover,
                    height: 50,
                    width: 70,
                  ),
                  Padding(
                    padding: EdgeInsets.all(16),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          _imagesAssets[index],
                          style: TextStyle(fontSize: 20),
                        ),
                        GestureDetector(
                          onTap: () {
                            setState(() {
                              _cartedImages[index] = !_cartedImages[index];
                            });
                          },
                          child: Stack(
                            children: [
                              Icon(
                                Icons.shopping_cart,
                                color: _cartedImages[index]
                                    ? Colors.green
                                    : Colors.black,
                              ),
                              Visibility(
                                visible: _cartedImages[index],
                                child: Positioned(
                                  top: 0,
                                  right: 0,
                                  child: Icon(
                                    Icons.check_circle,
                                    color: Colors.green,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        GestureDetector(
                          onTap: () {
                            setState(() {
                              _likedImages[index] = !_likedImages[index];
                            });
                          },
                          child: Stack(
                            children: [
                              Icon(
                                Icons.favorite,
                                color: _likedImages[index]
                                    ? Colors.red
                                    : Colors.black,
                              ),
                              Visibility(
                                visible: _likedImages[index],
                                child: Positioned(
                                  top: 0,
                                  right: 0,
                                  child: Icon(
                                    Icons.check_circle,
                                    color: Colors.red,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}