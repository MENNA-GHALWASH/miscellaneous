// import 'package:final_project/signIn.dart';
import 'package:final_project/signin2.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';

import 'GroceriesCart.dart';
import 'Signup.dart';
import 'appliancesCart.dart';
import 'clothesCart.dart';
import 'otherCart.dart';

void main() {
  runApp(MaterialApp(home: MyHomePage(),));
}

class MyHomePage extends StatefulWidget {


  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
 late VideoPlayerController controller ;

 void initState() {
   super.initState();
   controller = VideoPlayerController.asset('assets/v1.mp4')
     ..addListener(() => setState(() {}))
     ..setLooping(true)
     ..initialize().then((_) => controller.play());
 }

 @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  Widget build(BuildContext context) {

    /*Widget content(){
      return Container(
        width: 500,
        height: 300,
        child: _controller.value.isInitialized?VideoPlayer(_controller):Container(),
      );
    }*/


    return Scaffold(
      key: _scaffoldKey,
      appBar: AppBar(
        backgroundColor: Colors.deepPurpleAccent[100],
        title: Text('My shopping App'),
      ),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: <Widget>[
            DrawerHeader(
              child: Text('Item Categories:' , style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 20.0,
              ),  textAlign: TextAlign.center,
              ),
              decoration: BoxDecoration(
                color: Colors.deepPurpleAccent[100],
              ),
            ),
            ListTile(
              title: Text('Groceries'),
              onTap: () {
                Navigator.push(context, MaterialPageRoute(builder: (context) => Groc()));
              },
            ),
            ListTile(
              title: Text('Clothes'),
              onTap: () {
                Navigator.push(context, MaterialPageRoute(builder: (context) => ClothesCart()));
              },
            ),
            ListTile(
              title: Text('Appliances'),
              onTap: () {
                Navigator.push(context, MaterialPageRoute(builder: (context) => Cart()));
              },),
            ListTile(
              title: Text('Other'),
              onTap: () {
                Navigator.push(context, MaterialPageRoute(builder: (context) => OthCart()));
              },),
            Divider(),
            ListTile(
              title: Text('Sign in'),
              onTap: () {
                Navigator.push(context, MaterialPageRoute(builder: (context) => LoginPage()));
              },),
            ListTile(
              title: Text('Sign up'),
              onTap: () {
                Navigator.push(context,MaterialPageRoute(builder: (context)=>SignUp()));
              },),
          ],
        ),
      ),
      body: DefaultTabController(
        length: 3,
        child: Column(
          children: <Widget>[
            TabBar(

              unselectedLabelColor: Colors.deepPurpleAccent[400],
              indicatorColor: Colors.deepPurple[400],
              labelColor: Colors.black87,

              tabs: <Widget>[
                Tab(
                  icon: Icon(Icons.home),
                  text: 'Home',
                ),
                Tab(
                  icon: Icon(Icons.money_off),
                  text: 'Our latest offers',
                ),
                Tab(
                  icon: Icon(Icons.person),
                  text: 'Our statement',
                ),
              ],
            ),
            Expanded(
              child: TabBarView(
                children: <Widget>[
                  Center(
                    child: Column(
                      children: [ VideoPlayerWidget(controller : controller),
                      Image(image: AssetImage('assets/logo.jpg'),
                      width: 300,
                      height: 400,
                      )]
                    )
                  ), //first tab
                  Center(
                      child: GridView.count(
                        crossAxisCount: 2,
                        crossAxisSpacing: 7,

                          children: [
                            GestureDetector(
                              child: Image(image: AssetImage(
                                  'assets/g2.png'
                              )),
                              onTap: (){
                                Navigator.of(context).push( MaterialPageRoute(builder: (context) => Groc()));
                              },
                            ),
                            GestureDetector(
                              child: Image(image: AssetImage(
                                  'assets/c2.png'
                              )),
                              onTap: (){
                                Navigator.of(context).push( MaterialPageRoute(builder: (context) => ClothesCart()));
                              },
                            ),
                            GestureDetector(
                              child: Image(image: AssetImage(
                                  'assets/a2.png'
                              )),
                              onTap: (){
                                Navigator.of(context).push( MaterialPageRoute(builder: (context) => Cart()));
                              },
                            ),
                            GestureDetector(
                              child: Image(image: AssetImage(
                                  'assets/o2.png'
                              )),
                              onTap: (){
                                Navigator.of(context).push( MaterialPageRoute(builder: (context) => OthCart()));
                              },
                            ),

                          ],

                      )
                  ), // second tab
                  Center(
                    child:Text('We provide a fast comfortable and trusted service for our dedicate customers\n we beliee it is our sworn duty to help those who can not leave for shopping, we hope to provide you with the best online shopping experience',
                      style:TextStyle(fontStyle: FontStyle.italic,
                          fontSize: 30,
                          fontWeight: FontWeight.bold
                      ),
                    )
                  )
                      ]
                                    ),//third
                                  // ]
              ),
            // ),
          ],
        ),
      ),

    );

  }
}


class VideoPlayerWidget extends StatelessWidget {
  final VideoPlayerController controller;
  const VideoPlayerWidget({Key? key, required this.controller}) : super(key: key);

  @override
  Widget build(BuildContext context) =>
     /* controller != null &&*/ controller.value.isInitialized
          ? Container(alignment: Alignment.topCenter,child: buildVideo())
          : Container(
          height : 200,
          child:Center(child: CircularProgressIndicator())
  );

  Widget buildVideo() => buildVideoPlayer();

  Widget buildVideoPlayer() => VideoPlayer(controller);



}



class sidebar extends StatelessWidget {
  const sidebar({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return
    Drawer(
      child: ListView(
        padding: EdgeInsets.zero,
        children: <Widget>[
          DrawerHeader(
            child: Text('Item Categories:' , style: TextStyle(
              fontWeight: FontWeight.bold,
              fontSize: 20.0,
            ),  textAlign: TextAlign.center,
            ),
            decoration: BoxDecoration(
              color: Colors.deepPurpleAccent[100],
            ),
          ),
          ListTile(
            title: Text('Groceries'),
            onTap: () {
              Navigator.push(context, MaterialPageRoute(builder: (context) =>Groc()));
            },
          ),
          ListTile(
            title: Text('Clothes'),
            onTap: () {
              Navigator.of(context).push( MaterialPageRoute(builder: (context) => ClothesCart()));
            },
          ),
          ListTile(
            title: Text('Appliances'),
            onTap: () {
              Navigator.of(context).push( MaterialPageRoute(builder: (context) => Cart()));
            },),
          ListTile(
            title: Text('Other'),
            onTap: () {
              Navigator.of(context).push( MaterialPageRoute(builder: (context) => OthCart()));
            },),
          Divider(),
          ListTile(
            title: Text('Sign in'),
            onTap: () {
              Navigator.push(context, MaterialPageRoute(builder: (context) => LoginPage()));
            },),
          ListTile(
            title: Text('Sign up'),
            onTap: () {
              Navigator.push(context,MaterialPageRoute(builder: (context)=>SignUp()));
            },),
          Divider(),
          ListTile(
            title: Text('Home'),
            onTap: () {
              Navigator.push(context, MaterialPageRoute(builder: (context) => MyHomePage()));
            },)
        ],
      ),
    );
  }
}

/*
class tabbar extends StatelessWidget {
  tabbar({Key? key}) : super(key: key);

   Widget widget();
    tabContents(Widget widget){
    return widget;
   }

  @override
  Widget build(BuildContext context) {
    return  DefaultTabController(
      length: 3,
      child: Column(
        children: <Widget>[
          TabBar(

            unselectedLabelColor: Colors.deepPurpleAccent[400],
            indicatorColor: Colors.deepPurple[400],
            labelColor: Colors.black87,

            tabs: <Widget>[
              Tab(
                icon: Icon(Icons.home),
                text: 'Home',
              ),
              Tab(
                icon: Icon(Icons.money_off),
                text: 'Our latest offers',
              ),
              Tab(
                icon: Icon(Icons.person),
                text: 'Personal info',
              ),
            ],
          ),
          Expanded(
            child: TabBarView(
              children: <Widget>[
                Center(
                    child: Column(
                        children: [
                          VideoPlayerWidget(controller : _MyHomePageState().controller),
                          Image(image: AssetImage('assets/logoMM.png'),
                            width: 300,
                            height: 400,
                          )]
                    )
                ),
                Center(
                  child: tabContents(),
                ),
                Center(
                  child: Text('Tab 3 content'),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
*/

