import 'package:final_project/signIn.dart';
import 'package:flutter/material.dart';

void main() => runApp(const SignOut());

class SignOut extends StatelessWidget {
  const SignOut({Key? key}) : super(key: key);

  static const String _title = 'PRADA';

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: _title,
      home: Scaffold(
        appBar: AppBar(title: const Text(_title),
          backgroundColor: Colors.deepPurpleAccent[100],
        ),
        body: const MyStatefulWidget(),
      ),
    );
  }
}
class MyStatefulWidget extends StatefulWidget {
  const MyStatefulWidget({Key? key}) : super(key: key);

  @override
  State<MyStatefulWidget> createState() => _MyStatefulWidgetState();
}

class _MyStatefulWidgetState extends State<MyStatefulWidget> {
  TextEditingController nameController = TextEditingController();
  TextEditingController passwordController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Padding(
        padding: const EdgeInsets.all(10),

        child: ListView(
          children: <Widget>[
            Container(

                alignment: Alignment.center,
                padding: const EdgeInsets.all(10),
                child: Row(
                  children: [
                    const Text(
                      'Thank You For Your Visit',
                      style: TextStyle(
                        //  color:Color.fromARGB(255, 15, 0, 100),
                          fontWeight: FontWeight.bold,
                          fontSize: 35,
                          fontStyle: FontStyle.italic,
                          color: Colors.deepPurpleAccent
                      ),
                    ),
                  ],
                )),
            Divider(
              thickness: 10,
              color: Colors.deepPurple[600],
            ),
            Container(
                 margin:  const EdgeInsets.all(10.0),
                alignment: Alignment.center,
                padding: const EdgeInsets.all(10),
                child: const Text(
                  'Sign out',
                  style: TextStyle(fontSize: 40),

                )),
            Column(

              children: [
                Container(

            color: Colors.grey,
            margin: const EdgeInsets.all(10.0),
                  child: ElevatedButton.icon(


                      onPressed: () {
                        Navigator.push(context, MaterialPageRoute(builder: (context) => SignIn()));

                      },
                    icon: Icon( // <-- Icon
                      Icons.exit_to_app,
                      size: 35.0,

                    ),
                    label: Text('Sign Out',
                      style: TextStyle(
                        fontSize: 20,
                        backgroundColor: Colors.grey
                      ),

                    ), // <-- Text

                  ),
                ),
                Container(

                  color: Colors.grey,
                  margin: const EdgeInsets.all(10.0),
                  child: ElevatedButton.icon(
                    onPressed: () {},
                    icon: Icon( // <-- Icon
                      Icons.cancel,
                      size: 35.0,

                    ),
                    label: Text('Cancel',
                      style: TextStyle(
                        fontSize: 20,
                        backgroundColor: Colors.grey
                    ),), // <-- Text
                  ),
                ),
              ],

            ),

        ],
        ));
  }
}