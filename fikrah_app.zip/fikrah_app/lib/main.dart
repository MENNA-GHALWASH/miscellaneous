import 'package:flutter/material.dart';
//main function is the starting point for all the flutter apps
void main() {
  runApp(
    MaterialApp(
      home: Scaffold(
        backgroundColor: Colors.blueGrey[100],
        appBar: AppBar(
          title: Text('fikrah'),
          backgroundColor: Colors.deepPurpleAccent,
        ),
        body: Center(child:
        Image(
          image:AssetImage('images/wallpaper.jpeg'),
        ),
        )
      ),
      )
    ,);

}

